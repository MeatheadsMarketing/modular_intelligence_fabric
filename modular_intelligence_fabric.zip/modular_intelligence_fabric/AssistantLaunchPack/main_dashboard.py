"""
main_dashboard.py – Assistant Launch Pack v2.0

Central Streamlit entrypoint for AI system management and assistant orchestration.
"""

import streamlit as st
from pathlib import Path

st.set_page_config(page_title="Executive AI Dashboard", layout="wide")
st.title("Executive AI Control Center")

# Tabs to load (toggle with config later)
tabs = {
    "Assistant Overview": "tab_assistant_overview.py",
    "Logs Panel": "tab_logs_panel.py",
    "Insights Center": "tab_insights_center.py",
    "Workspace Bridge": "tab_workspace_bridge.py",
    "Memory Inspector": "tab_memory_inspector.py"
}

selected_tab = st.sidebar.selectbox("Navigate", list(tabs.keys()))
tab_path = tabs[selected_tab]

# Load and run selected tab
tab_file = Path("tabs") / tab_path
if tab_file.exists():
    with open(tab_file) as f:
        exec(f.read())
else:
    st.warning(f"Tab file not found: {tab_path}")
