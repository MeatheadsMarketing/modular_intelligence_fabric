import streamlit as st
import json
import os
from datetime import datetime

st.set_page_config(page_title="Delegation History")
st.title("Delegation Log")

LOG_PATH = "delegation_log.json"

if os.path.exists(LOG_PATH):
    with open(LOG_PATH, "r") as f:
        logs = json.load(f)
else:
    logs = []

# Search and filter
search = st.text_input("Search by prompt or agent")
if search:
    logs = [l for l in logs if search.lower() in l.get("prompt", "").lower() or search.lower() in l.get("assigned_to", "").lower()]

# Display
st.subheader(f"Delegation Entries ({len(logs)})")
for entry in reversed(logs[-25:]):
    st.markdown("----")
    st.markdown(f"**Agent:** `{entry.get('assigned_to', 'unknown')}`")
    st.markdown(f"**Prompt:** {entry.get('prompt', '')}")
    st.caption(f"🕒 {entry.get('timestamp', '')}")
