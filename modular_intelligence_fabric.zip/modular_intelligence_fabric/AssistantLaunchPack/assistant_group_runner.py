"""
assistant_group_runner.py – Assistant Launch Pack v2.2

Executes multi-assistant chains based on group config.
Each assistant takes the prior assistant's output as its input.
"""

import json
import os
from datetime import datetime
from flow_runner import run_flow, step_echo

GROUP_CONFIG = "group_config.json"
GROUP_LOG = "group_log.json"

def load_group(group_name):
    if not os.path.exists(GROUP_CONFIG):
        return []
    with open(GROUP_CONFIG) as f:
        config = json.load(f)
    return config.get(group_name, [])

def log_group_run(group_name, steps):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "group": group_name,
        "steps": steps
    }

    log = []
    if os.path.exists(GROUP_LOG):
        with open(GROUP_LOG, "r") as f:
            log = json.load(f)

    log.append(entry)
    with open(GROUP_LOG, "w") as f:
        json.dump(log, f, indent=2)

def run_group_task(group_name, starting_prompt):
    assistants = load_group(group_name)
    steps = []
    prompt = starting_prompt

    for assistant in assistants:
        result = run_flow(prompt, steps=[step_echo])  # placeholder logic
        output = result["steps"][-1]["output"]
        steps.append({
            "assistant": assistant,
            "input": prompt,
            "output": output
        })
        prompt = output

    log_group_run(group_name, steps)
    return steps

# Example run
if __name__ == "__main__":
    result = run_group_task("ProductLaunchPrep", "Generate product tagline")
    for step in result:
        print(f"{step['assistant']}: {step['output']}")
