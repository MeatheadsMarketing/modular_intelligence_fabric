"""
agent_router.py – Assistant Launch Pack v2.1

Routes prompts to the correct assistant based on keyword, tags, or config logic.
"""

import json
import os
from datetime import datetime

ROUTER_RULES_FILE = "router_rules.json"
DELEGATION_LOG_FILE = "delegation_log.json"

def load_rules():
    if os.path.exists(ROUTER_RULES_FILE):
        with open(ROUTER_RULES_FILE) as f:
            return json.load(f).get("routes", [])
    return []

def log_delegation(prompt, assistant):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "prompt": prompt,
        "assigned_to": assistant
    }

    log = []
    if os.path.exists(DELEGATION_LOG_FILE):
        with open(DELEGATION_LOG_FILE) as f:
            log = json.load(f)

    log.append(entry)
    with open(DELEGATION_LOG_FILE, "w") as f:
        json.dump(log, f, indent=2)

def route_prompt(prompt):
    rules = load_rules()
    for rule in rules:
        keywords = rule.get("keywords", [])
        if any(word.lower() in prompt.lower() for word in keywords):
            assistant = rule.get("assistant")
            log_delegation(prompt, assistant)
            return assistant
    log_delegation(prompt, "default")
    return "default"

# Example usage
if __name__ == "__main__":
    result = route_prompt("optimize this email subject line")
    print("✅ Routed to:", result)
