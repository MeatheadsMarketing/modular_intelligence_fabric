"""
client_script_template.py – Assistant Launch Pack v1.6

Use this script to trigger assistants via the assistant API.
Send a POST request with a prompt and optional assistant name.
"""

import requests
import json

API_URL = "http://localhost:8080"
HEADERS = {"Content-Type": "application/json"}

def trigger_assistant(prompt, assistant_name="default"):
    payload = {
        "prompt": prompt,
        "assistant": assistant_name
    }
    try:
        response = requests.post(API_URL, headers=HEADERS, data=json.dumps(payload))
        if response.status_code == 200:
            data = response.json()
            print("✅ Assistant Response:")
            print(json.dumps(data, indent=2))
        else:
            print("❌ API Error:", response.status_code)
            print(response.text)
    except Exception as e:
        print("❌ Request failed:", str(e))

# Example
if __name__ == "__main__":
    prompt = "Summarize my calendar for the day"
    trigger_assistant(prompt, assistant_name="calendar_summary")
