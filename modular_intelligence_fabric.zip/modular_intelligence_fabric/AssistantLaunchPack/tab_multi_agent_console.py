import streamlit as st
import json
import os
from agent_router import route_prompt
from agent_status import get_status, set_status

st.set_page_config(page_title="Multi-Agent Console")
st.title("Multi-Agent Console")

# Load agents and profiles
AGENTS_FILE = "agent_registry.json"
PROFILES_FILE = "assistant_profiles.json"

if os.path.exists(AGENTS_FILE):
    with open(AGENTS_FILE, "r") as f:
        agents = json.load(f).get("agents", [])
else:
    agents = []

if os.path.exists(PROFILES_FILE):
    with open(PROFILES_FILE, "r") as f:
        profiles = json.load(f)
else:
    profiles = {}

# Run interface
st.subheader("Delegate a Task")
user_prompt = st.text_area("Enter your task")

if st.button("Route and Trigger Assistant"):
    routed = route_prompt(user_prompt)
    set_status(routed, "running")
    st.success(f"Prompt routed to: {routed}")
    profile = profiles.get(routed, {})
    st.markdown(f"**Tone:** {profile.get('tone')}")
    st.markdown(f"**Skills:** {', '.join(profile.get('skills', []))}")
    st.markdown(f"**Goal:** {profile.get('goal')}")
