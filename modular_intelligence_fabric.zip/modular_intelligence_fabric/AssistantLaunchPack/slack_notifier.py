"""
slack_notifier.py – Assistant Launch Pack v1.9

Send Slack alerts from assistant activity (status, summary, trigger events).
"""

import os
import requests

SLACK_WEBHOOK_URL = os.getenv("SLACK_WEBHOOK_URL", "https://hooks.slack.com/services/your/default/hook")

def send_slack_alert(message, channel="#general"):
    payload = {
        "text": message,
        "channel": channel
    }

    try:
        response = requests.post(SLACK_WEBHOOK_URL, json=payload)
        if response.status_code == 200:
            print("✅ Slack alert sent.")
        else:
            print(f"❌ Slack failed: {response.status_code} | {response.text}")
    except Exception as e:
        print("❌ Exception sending to Slack:", str(e))

# Example usage
if __name__ == "__main__":
    send_slack_alert("Test alert from Assistant Launch Pack.")
