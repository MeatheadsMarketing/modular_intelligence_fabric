import streamlit as st
import os
from notion_connector import push_to_notion

st.set_page_config(page_title="Workspace Bridge")
st.title("Workspace Integration Hub")

st.markdown("Use this tab to push data to connected services like Notion, Google Drive, or Slack.")

# Example Notion sync
st.subheader("Push to Notion")
title = st.text_input("Title", "Sync Test from Streamlit")
content = st.text_area("Content", "This is a manually triggered test sync.")
tags = st.text_input("Tags (comma-separated)", "test,manual").split(",")

if st.button("Sync to Notion"):
    push_to_notion(title, content, tags=[tag.strip() for tag in tags if tag.strip()])
    st.success("Notion sync triggered.")

st.markdown("---")
st.info("More integrations (Drive, Slack, Calendar) coming in this tab.")
