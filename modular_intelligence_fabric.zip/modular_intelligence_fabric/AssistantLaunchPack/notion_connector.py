"""
notion_connector.py – Assistant Launch Pack v1.9

Sync logs or summaries into Notion via the Notion API.
"""

import os
import json
import requests
from datetime import datetime

NOTION_API_URL = "https://api.notion.com/v1/pages"
NOTION_DB_ID = os.getenv("NOTION_DB_ID", "your-database-id")
NOTION_TOKEN = os.getenv("NOTION_API_KEY", "your-secret-token")

HEADERS = {
    "Authorization": f"Bearer {NOTION_TOKEN}",
    "Notion-Version": "2022-06-28",
    "Content-Type": "application/json"
}

def push_to_notion(title, content, tags=None):
    payload = {
        "parent": {"database_id": NOTION_DB_ID},
        "properties": {
            "Title": {"title": [{"text": {"content": title}}]},
            "Tags": {"multi_select": [{"name": tag} for tag in (tags or [])]},
            "Timestamp": {"date": {"start": datetime.utcnow().isoformat()}}
        },
        "children": [
            {
                "object": "block",
                "type": "paragraph",
                "paragraph": {"text": [{"type": "text", "text": {"content": content}}]}
            }
        ]
    }

    try:
        res = requests.post(NOTION_API_URL, headers=HEADERS, json=payload)
        if res.status_code == 200:
            print(f"✅ Synced to Notion: {title}")
        else:
            print(f"❌ Notion sync failed ({res.status_code}):", res.text)
    except Exception as e:
        print("❌ Exception during Notion sync:", str(e))

# Example usage
if __name__ == "__main__":
    push_to_notion("Memory Summary – v1.8", "This is a test summary pushed from v1.9-prep.", tags=["memory", "summary"])
