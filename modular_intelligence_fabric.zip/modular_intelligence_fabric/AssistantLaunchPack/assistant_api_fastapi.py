"""
assistant_api_fastapi.py – Assistant Launch Pack v1.6+

Run assistant via FastAPI server for remote, mobile, or integrated trigger calls.
"""

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from flow_runner import run_flow, step_echo
import uvicorn

app = FastAPI()

@app.post("/run")
async def run_assistant(request: Request):
    try:
        data = await request.json()
        prompt = data.get("prompt", "")
        assistant = data.get("assistant", "default")
        steps = [step_echo]  # Extendable
        result = run_flow(prompt, steps)

        return JSONResponse(status_code=200, content={
            "status": "success",
            "assistant": assistant,
            "data": result
        })
    except Exception as e:
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})

if __name__ == "__main__":
    uvicorn.run("assistant_api_fastapi:app", host="0.0.0.0", port=8080, reload=True)
