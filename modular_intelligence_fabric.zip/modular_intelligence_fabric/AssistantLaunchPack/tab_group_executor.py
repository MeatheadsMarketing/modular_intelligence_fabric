import streamlit as st
import json
import os
from assistant_group_runner import run_group_task

st.set_page_config(page_title="Group Executor")
st.title("Multi-Assistant Group Task Executor")

CONFIG_PATH = "group_config.json"
GROUP_LOG = "group_log.json"

if os.path.exists(CONFIG_PATH):
    with open(CONFIG_PATH) as f:
        groups = json.load(f)
else:
    groups = {}

group_name = st.selectbox("Select Assistant Group", list(groups.keys()))

prompt = st.text_area("Starting Prompt", "Draft a product launch plan.")

if st.button("Run Group Task"):
    result = run_group_task(group_name, prompt)
    st.success("Task executed.")
    for step in result:
        st.markdown("----")
        st.markdown(f"**Assistant:** `{step['assistant']}`")
        st.markdown(f"**Input:** {step['input']}")
        st.markdown(f"**Output:** {step['output']}")
