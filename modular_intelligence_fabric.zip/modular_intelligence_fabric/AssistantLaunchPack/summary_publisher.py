"""
summary_publisher.py – Assistant Launch Pack v1.9

Pushes the latest memory summary or assistant output to all enabled integrations.
"""

import json
import os
from datetime import datetime
from notion_connector import push_to_notion
from slack_notifier import send_slack_alert
from drive_uploader import upload_to_drive
from calendar_logger import create_event

CONFIG_PATH = "workspace_config.json"
SUMMARY_PATH = "memory_summary.json"

def load_summary():
    if not os.path.exists(SUMMARY_PATH):
        return "No summary available."
    with open(SUMMARY_PATH, "r") as f:
        entries = json.load(f)
    return entries[-1]["summary"]

def load_config():
    if not os.path.exists(CONFIG_PATH):
        return {}
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)

def publish_all():
    summary = load_summary()
    config = load_config()
    title = f"Assistant Summary – {datetime.utcnow().isoformat()}"

    if config.get("notion", {}).get("enabled"):
        push_to_notion(title, summary, tags=["auto", "v1.9"])

    if config.get("slack", {}).get("enabled"):
        send_slack_alert(f"*Assistant Summary:* {summary[:200]}...")

    if config.get("google_drive", {}).get("enabled"):
        upload_to_drive(SUMMARY_PATH)

    if config.get("google_calendar", {}).get("enabled"):
        create_event("Assistant Summary: " + title, summary)

    print("✅ All active workspace integrations triggered.")

if __name__ == "__main__":
    publish_all()
