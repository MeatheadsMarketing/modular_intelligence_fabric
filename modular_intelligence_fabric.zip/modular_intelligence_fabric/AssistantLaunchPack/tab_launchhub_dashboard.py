import streamlit as st
import json
import os

st.set_page_config(page_title="LaunchHub Dashboard")
st.title("Assistant LaunchHub")

# Load agent registry
REGISTRY_PATH = "agent_registry.json"
status_file = "agent_status.json"
version_files = ["v1.1", "v1.2", "v1.3", "v1.4", "v1.5", "v1.6"]

if os.path.exists(REGISTRY_PATH):
    with open(REGISTRY_PATH, "r") as f:
        registry = json.load(f)
else:
    registry = {"agents": []}

if os.path.exists(status_file):
    with open(status_file, "r") as f:
        status_map = json.load(f)
else:
    status_map = {}

# Optional filter
version_filter = st.sidebar.selectbox("Filter by Version Tag", ["All"] + version_files)
tier_filter = st.sidebar.selectbox("Filter by Tier", ["All", "Free", "Pro", "Enterprise"])

# Filtered display
filtered = []
for agent in registry.get("agents", []):
    tier = agent.get("tier", "Free")
    tags = agent.get("tags", [])
    name = agent.get("name", "")
    version = agent.get("version", "v1.5")
    if (tier_filter == "All" or tier == tier_filter) and (version_filter == "All" or version == version_filter):
        filtered.append(agent)

# Display agents
for agent in filtered:
    name = agent.get("name", "Unnamed")
    tags = ", ".join(agent.get("tags", []))
    tier = agent.get("tier", "Free")
    version = agent.get("version", "v1.5")
    status = status_map.get(name, "idle")
    with st.container():
        st.subheader(name)
        st.markdown(f"**Tags:** {tags}")
        st.markdown(f"**Tier:** `{tier}`")
        st.markdown(f"**Version:** `{version}`")
        st.markdown(f"**Status:** `{status}`")
        col1, col2 = st.columns(2)
        if col1.button(f"Run {name} (API)", key=f"{name}_run"):
            st.success(f"POST to /run assistant with name: {name}")
        if col2.button(f"Set {name} Idle", key=f"{name}_idle"):
            status_map[name] = "idle"
            with open(status_file, "w") as f:
                json.dump(status_map, f, indent=2)
            st.experimental_rerun()
