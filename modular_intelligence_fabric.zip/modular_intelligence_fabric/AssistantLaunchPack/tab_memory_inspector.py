import streamlit as st
import json
import os

st.set_page_config(page_title="Memory Inspector")
st.title("Memory Inspector")

LOG_FILE = "memory_log.json"

# Load memory
if os.path.exists(LOG_FILE):
    with open(LOG_FILE, "r") as f:
        logs = json.load(f)
else:
    logs = []

# Search input
query = st.text_input("Search keyword", "")

# Filtered display
if query:
    filtered = [e for e in logs if query.lower() in e["prompt"].lower() or query.lower() in e["response"].lower()]
else:
    filtered = logs[-10:]  # Show last 10 if no search

if filtered:
    for entry in reversed(filtered):
        st.markdown(f"### {entry['assistant']} – {entry['timestamp']}")
        st.markdown(f"**Prompt:** {entry['prompt']}")
        st.caption(f"Response: {entry['response']}")
        if entry.get("tags"):
            st.caption(f"Tags: {', '.join(entry['tags'])}")
else:
    st.info("No entries found.")
