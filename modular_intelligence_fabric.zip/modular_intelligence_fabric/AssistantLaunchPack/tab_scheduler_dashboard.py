import streamlit as st
import json
import os
from datetime import datetime

st.set_page_config(page_title="Scheduler Dashboard")
st.title("Assistant Scheduler Dashboard")

TRIGGER_PATH = "trigger_rules.json"

# Load or init triggers
if os.path.exists(TRIGGER_PATH):
    with open(TRIGGER_PATH, "r") as f:
        data = json.load(f)
else:
    data = {"triggers": []}

triggers = data.get("triggers", [])

# Show existing triggers
st.subheader("Scheduled Triggers")
for t in triggers:
    st.markdown(f"• **{t['name']}** → every `{t['interval']}s`")
    st.caption(f"Prompt: {t['prompt']}")
    if "last_run" in t and t["last_run"] > 0:
        st.caption(f"Last run: {datetime.utcfromtimestamp(t['last_run'])}")

# Add new trigger
st.markdown("---")
st.subheader("Add New Trigger")
with st.form("new_trigger_form"):
    name = st.text_input("Name")
    prompt = st.text_area("Prompt")
    interval = st.number_input("Interval (seconds)", min_value=10, value=3600)
    submit = st.form_submit_button("Add Trigger")

if submit and name and prompt:
    triggers.append({
        "name": name,
        "prompt": prompt,
        "interval": interval,
        "last_run": 0
    })
    with open(TRIGGER_PATH, "w") as f:
        json.dump({"triggers": triggers}, f, indent=2)
    st.success(f"Added trigger: {name}")
    st.experimental_rerun()
