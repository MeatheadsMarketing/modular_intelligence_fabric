"""
memory_embedder.py – Assistant Launch Pack v1.8

Encodes memory log entries into semantic embeddings for vector search or summarization.
"""

import json
import os
from openai import OpenAI
from datetime import datetime

MEMORY_LOG = "memory_log.json"
MEMORY_INDEX = "memory_index.json"
MODEL = "text-embedding-ada-002"

client = OpenAI()

def load_memory():
    if not os.path.exists(MEMORY_LOG):
        return []
    with open(MEMORY_LOG, "r") as f:
        return json.load(f)

def embed_text(text):
    try:
        response = client.embeddings.create(
            model=MODEL,
            input=text
        )
        return response.data[0].embedding
    except Exception as e:
        print("❌ Embedding error:", str(e))
        return []

def build_index():
    memory = load_memory()
    index = []

    for entry in memory:
        combined = f"{entry['prompt']} || {entry['response']}"
        vector = embed_text(combined)
        index.append({
            "id": entry.get("timestamp"),
            "assistant": entry.get("assistant", "default"),
            "embedding": vector,
            "prompt": entry["prompt"],
            "response": entry["response"]
        })

    with open(MEMORY_INDEX, "w") as f:
        json.dump(index, f, indent=2)

    print(f"✅ Indexed {len(index)} memory entries.")

if __name__ == "__main__":
    build_index()
