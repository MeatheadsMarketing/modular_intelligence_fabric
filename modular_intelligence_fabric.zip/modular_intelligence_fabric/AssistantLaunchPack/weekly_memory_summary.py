"""
weekly_memory_summary.py – Assistant Launch Pack v1.8

Summarizes assistant memory logs using OpenAI GPT.
"""

import json
import os
from datetime import datetime
from openai import OpenAI

MEMORY_LOG_FILE = "memory_log.json"
SUMMARY_FILE = "memory_summary.json"

client = OpenAI()
model = "gpt-4"

def load_logs():
    if not os.path.exists(MEMORY_LOG_FILE):
        return []
    with open(MEMORY_LOG_FILE, "r") as f:
        return json.load(f)

def summarize_logs(entries):
    combined = "\n\n".join([f"Prompt: {e['prompt']}\nResponse: {e['response']}" for e in entries])
    prompt = f"Summarize the following assistant log entries. Focus on major themes, tasks completed, and recurring patterns.\n\n{combined}"

    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"❌ GPT Error: {str(e)}"

def write_summary(summary_text):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "summary": summary_text
    }

    summaries = []
    if os.path.exists(SUMMARY_FILE):
        with open(SUMMARY_FILE, "r") as f:
            summaries = json.load(f)

    summaries.append(entry)
    with open(SUMMARY_FILE, "w") as f:
        json.dump(summaries, f, indent=2)

    print("✅ Summary written.")

if __name__ == "__main__":
    logs = load_logs()
    if logs:
        summary = summarize_logs(logs[-15:])  # summarize last 15 entries
        write_summary(summary)
        print(summary)
    else:
        print("No logs to summarize.")
