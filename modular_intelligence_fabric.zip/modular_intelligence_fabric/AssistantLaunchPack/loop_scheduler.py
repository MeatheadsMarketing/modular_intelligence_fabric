"""
loop_scheduler.py – Assistant Launch Pack v1.7

Runs assistants on a scheduled interval using a local event loop.
Future-proofed for integration with cron or calendar triggers.
"""

import time
import json
import os
from datetime import datetime
from flow_runner import run_flow, step_echo

TRIGGERS_FILE = "trigger_rules.json"
LOOP_LOG_FILE = "loop_log.json"

def load_triggers():
    if not os.path.exists(TRIGGERS_FILE):
        return []
    with open(TRIGGERS_FILE, "r") as f:
        return json.load(f).get("triggers", [])

def log_loop_result(name, result):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "assistant": name,
        "result": result
    }
    logs = []
    if os.path.exists(LOOP_LOG_FILE):
        with open(LOOP_LOG_FILE, "r") as f:
            logs = json.load(f)
    logs.append(entry)
    with open(LOOP_LOG_FILE, "w") as f:
        json.dump(logs, f, indent=2)

def loop_scheduler():
    print("🔁 Loop scheduler started.")
    while True:
        triggers = load_triggers()
        for trigger in triggers:
            name = trigger.get("name", "Unnamed")
            interval = trigger.get("interval", 60)  # seconds
            last_run = trigger.get("last_run", 0)
            now = time.time()

            if now - last_run >= interval:
                print(f"⏱ Running: {name}")
                result = run_flow(trigger.get("prompt", ""), steps=[step_echo])
                log_loop_result(name, result)

                # Update last_run
                trigger["last_run"] = now
        with open(TRIGGERS_FILE, "w") as f:
            json.dump({"triggers": triggers}, f, indent=2)
        time.sleep(10)

if __name__ == "__main__":
    loop_scheduler()
