import streamlit as st
import json
import os
from datetime import datetime

st.set_page_config(page_title="Service Monitor")
st.title("Assistant Service Monitor")

# Load usage log
usage_file = "usage_log.json"
if os.path.exists(usage_file):
    with open(usage_file) as f:
        usage = json.load(f)
    st.subheader("Usage History")
    for entry in reversed(usage[-10:]):
        ts = entry.get("timestamp")
        user = entry.get("user", "unknown")
        prompt = entry.get("prompt", "")
        assistant = entry.get("assistant", "default")
        st.markdown(f"• **{assistant}** by `{user}` at `{ts}` → *{prompt}*")
else:
    st.info("No usage_log.json found yet.")

# Show summary stats
if usage:
    total = len(usage)
    unique_users = len(set(e.get("user", "unknown") for e in usage))
    assistants = set(e.get("assistant", "default") for e in usage)
    st.subheader("System Summary")
    st.write(f"Total runs: {total}")
    st.write(f"Unique users: {unique_users}")
    st.write(f"Assistants triggered: {', '.join(assistants)}")

# Optional: last modified indicator
status_file = "agent_status.json"
if os.path.exists(status_file):
    modified = datetime.utcfromtimestamp(os.path.getmtime(status_file))
    st.caption(f"Status file last modified: {modified.isoformat()} UTC")
