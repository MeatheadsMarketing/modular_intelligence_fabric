"""
semantic_memory.py – Assistant Launch Pack v1.8

This module encodes and stores assistant sessions for recall via keyword or vector search.
"""

import json
import os
from datetime import datetime

MEMORY_LOG_FILE = "memory_log.json"

def log_memory(prompt, response, assistant="default", tags=None):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "assistant": assistant,
        "prompt": prompt,
        "response": response,
        "tags": tags or []
    }

    if os.path.exists(MEMORY_LOG_FILE):
        with open(MEMORY_LOG_FILE, "r") as f:
            logs = json.load(f)
    else:
        logs = []

    logs.append(entry)

    with open(MEMORY_LOG_FILE, "w") as f:
        json.dump(logs, f, indent=2)

    print(f"✅ Memory saved: {assistant} | {prompt[:50]}...")

def search_memory(keyword):
    if not os.path.exists(MEMORY_LOG_FILE):
        return []

    with open(MEMORY_LOG_FILE, "r") as f:
        logs = json.load(f)

    matches = [e for e in logs if keyword.lower() in e["prompt"].lower() or keyword.lower() in e["response"].lower()]
    return matches

# Example usage
if __name__ == "__main__":
    log_memory("What did I do yesterday?", "You used the dashboard to run Content Generator.")
    results = search_memory("dashboard")
    print("Found:", results)
