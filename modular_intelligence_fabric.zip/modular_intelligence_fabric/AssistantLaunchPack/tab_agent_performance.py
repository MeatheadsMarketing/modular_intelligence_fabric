import streamlit as st
import pandas as pd
from performance_score import score_assistants

st.set_page_config(page_title="Agent Performance")
st.title("Agent Performance Dashboard")

scores = score_assistants()

if scores:
    df = pd.DataFrame.from_dict(scores, orient="index")
    df = df.sort_values(by="score", ascending=False)
    st.subheader("Agent Ranking")
    st.dataframe(df)
else:
    st.info("No delegation or loop log data available.")
