import streamlit as st
import json
import os

st.title("Logs Panel")

LOG_TYPES = {
    "Memory Log": "memory_log.json",
    "Usage Log": "usage_log.json",
    "Feedback Log": "feedback_log.json"
}

log_type = st.sidebar.selectbox("Select Log Type", list(LOG_TYPES.keys()))
log_file = LOG_TYPES[log_type]

if os.path.exists(log_file):
    with open(log_file) as f:
        entries = json.load(f)
else:
    entries = []

# Search box
search_query = st.text_input("Search logs", "")
if search_query:
    entries = [e for e in entries if search_query.lower() in json.dumps(e).lower()]

# Display logs
st.subheader(f"{log_type} ({len(entries)} entries)")
for entry in reversed(entries[-25:]):
    st.markdown("----")
    for k, v in entry.items():
        st.markdown(f"**{k}**: `{str(v)}`")
