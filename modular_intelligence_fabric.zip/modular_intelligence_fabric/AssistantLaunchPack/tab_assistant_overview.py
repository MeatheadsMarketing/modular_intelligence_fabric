import streamlit as st
import json
import os

st.title("Assistant Overview")

registry_path = "agent_registry.json"
status_path = "agent_status.json"
usage_path = "usage_log.json"

# Load data
agents = []
statuses = {}
usage_log = []

if os.path.exists(registry_path):
    with open(registry_path) as f:
        agents = json.load(f).get("agents", [])

if os.path.exists(status_path):
    with open(status_path) as f:
        statuses = json.load(f)

if os.path.exists(usage_path):
    with open(usage_path) as f:
        usage_log = json.load(f)

# Overview table
st.subheader("Assistants")
for agent in agents:
    name = agent.get("name", "Unnamed")
    tags = ", ".join(agent.get("tags", []))
    tier = agent.get("tier", "Free")
    status = statuses.get(name, "idle")
    runs = sum(1 for u in usage_log if u.get("assistant") == name)

    with st.container():
        st.markdown(f"### {name}")
        st.markdown(f"**Tier:** `{tier}` | **Tags:** {tags}")
        st.markdown(f"**Status:** `{status}` | **Runs:** `{runs}`")

        col1, col2 = st.columns(2)
        if col1.button(f"Simulate Trigger: {name}", key=f"{name}_trigger"):
            st.success(f"{name} triggered.")
        if col2.button(f"Reset Status: {name}", key=f"{name}_reset"):
            statuses[name] = "idle"
            with open(status_path, "w") as f:
                json.dump(statuses, f, indent=2)
            st.experimental_rerun()
