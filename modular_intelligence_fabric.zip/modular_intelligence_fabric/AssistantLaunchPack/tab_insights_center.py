import streamlit as st
import json
import os
from openai import OpenAI

st.title("Insights Center")

LOG_FILE = "memory_log.json"
SUMMARY_LIMIT = 15
MODEL = "gpt-4"

client = OpenAI()

def load_memory():
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r") as f:
            return json.load(f)[-SUMMARY_LIMIT:]
    return []

def generate_insight(entries):
    combined = "\n\n".join([f"Prompt: {e['prompt']}\nResponse: {e['response']}" for e in entries])
    prompt = f"Based on the following assistant interactions, summarize key themes, user intent, and recommended actions:\n\n{combined}"
    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"❌ GPT Error: {str(e)}"

# Trigger button
entries = load_memory()
if st.button("Generate Insight Summary"):
    if entries:
        summary = generate_insight(entries)
        st.markdown("### Summary Output")
        st.write(summary)
    else:
        st.warning("No memory log entries found.")
