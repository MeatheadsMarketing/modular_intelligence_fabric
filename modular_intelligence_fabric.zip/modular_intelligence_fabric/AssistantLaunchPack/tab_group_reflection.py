import streamlit as st
import json
import os
from group_reflector import load_last_group_run, reflect_on_group_run, save_reflection

st.set_page_config(page_title="Group Reflection")
st.title("Group Output Reflection")

REFLECTION_LOG = "group_reflection.json"

entry = load_last_group_run()
if entry:
    st.markdown(f"**Group:** `{entry['group']}`")
    for step in entry["steps"]:
        st.markdown(f"• `{step['assistant']}` → {step['output']}")

    if st.button("Run Reflection Summary"):
        summary = reflect_on_group_run(entry)
        save_reflection(summary, entry["group"])
        st.subheader("Reflection Output")
        st.write(summary)
else:
    st.info("No group log available.")

# Show previous reflections
if os.path.exists(REFLECTION_LOG):
    with open(REFLECTION_LOG) as f:
        reflections = json.load(f)
    st.subheader("Past Reflections")
    for r in reversed(reflections[-3:]):
        st.markdown("----")
        st.markdown(f"**{r['group']} – {r['timestamp']}**")
        st.write(r["summary"])
