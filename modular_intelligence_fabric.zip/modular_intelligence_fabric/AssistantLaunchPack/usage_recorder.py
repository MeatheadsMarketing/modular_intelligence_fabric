"""
usage_recorder.py – Assistant Launch Pack v1.6

Logs assistant usage per call:
- Who ran it
- What was prompted
- When it was run
- What assistant/flow was used
"""

import json
import os
from datetime import datetime

USAGE_LOG_FILE = "usage_log.json"

def log_usage(prompt, assistant_name="default", user="local"):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "user": user,
        "assistant": assistant_name,
        "prompt": prompt
    }

    if os.path.exists(USAGE_LOG_FILE):
        with open(USAGE_LOG_FILE, "r") as f:
            logs = json.load(f)
    else:
        logs = []

    logs.append(entry)

    with open(USAGE_LOG_FILE, "w") as f:
        json.dump(logs, f, indent=2)

    print(f"✅ Usage logged for: {assistant_name} by {user}")

# Example usage
if __name__ == "__main__":
    log_usage("Test prompt for productivity tracking", "v1.6-api-test", "test_user")
