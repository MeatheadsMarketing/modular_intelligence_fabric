"""
agent_loop_runner.py – Assistant Launch Pack v1.7

Run assistant in a loop until:
- token cap reached
- stop condition matched
- max iterations exceeded
"""

import json
import os
from datetime import datetime
from flow_runner import run_flow, step_echo

LOOP_LOG_FILE = "loop_log.json"
STOP_PHRASES = ["summary complete", "task complete", "end of loop"]

def run_looped_assistant(prompt, max_loops=5):
    log = []
    for i in range(max_loops):
        print(f"🔁 Loop {i+1}")
        result = run_flow(prompt, steps=[step_echo])
        output = result.get("steps", [])[-1].get("output", "")

        entry = {
            "loop": i + 1,
            "timestamp": datetime.utcnow().isoformat(),
            "input": prompt,
            "output": output
        }
        log.append(entry)

        if any(stop in output.lower() for stop in STOP_PHRASES):
            entry["stopped"] = True
            print(f"⛔️ Stop condition met: {output}")
            break

        prompt = output  # Pass output into next round

    # Save loop log
    logs = []
    if os.path.exists(LOOP_LOG_FILE):
        with open(LOOP_LOG_FILE, "r") as f:
            logs = json.load(f)
    logs.append({
        "session": datetime.utcnow().isoformat(),
        "runs": log
    })
    with open(LOOP_LOG_FILE, "w") as f:
        json.dump(logs, f, indent=2)

    return log

# Example run
if __name__ == "__main__":
    run_looped_assistant("start loop")
