import streamlit as st
import json
import os
from datetime import datetime

st.set_page_config(page_title="Loop Inspector")
st.title("Agent Loop Inspector")

LOOP_LOG_FILE = "loop_log.json"

if os.path.exists(LOOP_LOG_FILE):
    with open(LOOP_LOG_FILE, "r") as f:
        logs = json.load(f)
    st.subheader("Loop Sessions")
    for session in reversed(logs[-5:]):
        st.markdown(f"### Session: `{session['session']}`")
        for entry in session.get("runs", []):
            st.write(f"Loop {entry['loop']} | Prompt → `{entry['input']}`")
            st.caption(f"Response → {entry['output']}")
            if entry.get("stopped"):
                st.warning("⛔️ Stop condition met")
else:
    st.info("No loop_log.json file found yet.")

# Optionally display number of loops
st.markdown("---")
if logs:
    total = sum(len(s.get("runs", [])) for s in logs)
    st.caption(f"Total looped steps logged: {total}")
