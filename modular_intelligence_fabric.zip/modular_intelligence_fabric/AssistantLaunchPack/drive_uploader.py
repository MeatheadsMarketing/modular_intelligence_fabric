"""
drive_uploader.py – Assistant Launch Pack v1.9

Uploads selected files to Google Drive using service account.
"""

import os
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

SCOPES = ["https://www.googleapis.com/auth/drive.file"]
SERVICE_ACCOUNT_FILE = os.getenv("GOOGLE_SERVICE_ACCOUNT_JSON", "your-service-account.json")
DRIVE_FOLDER_ID = os.getenv("DRIVE_FOLDER_ID", "your-google-drive-folder-id")

def upload_to_drive(local_file_path):
    creds = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)

    service = build("drive", "v3", credentials=creds)

    file_metadata = {
        "name": os.path.basename(local_file_path),
        "parents": [DRIVE_FOLDER_ID]
    }

    media = MediaFileUpload(local_file_path, resumable=True)

    try:
        file = service.files().create(
            body=file_metadata,
            media_body=media,
            fields="id"
        ).execute()
        print(f"✅ Uploaded to Drive: {file.get('id')}")
    except Exception as e:
        print(f"❌ Upload failed: {str(e)}")

# Example usage
if __name__ == "__main__":
    upload_to_drive("memory_log.json")
