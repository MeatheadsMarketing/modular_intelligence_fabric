"""
performance_score.py – Assistant Launch Pack v2.1

Calculates performance score per assistant based on:
- Frequency of delegation
- Stop condition success
- Recency of usage
"""

import json
import os
from datetime import datetime

DELEGATION_LOG = "delegation_log.json"
LOOP_LOG = "loop_log.json"

def score_assistants():
    if not os.path.exists(DELEGATION_LOG):
        return {}

    with open(DELEGATION_LOG, "r") as f:
        delegation_entries = json.load(f)

    usage_count = {}
    last_used = {}
    for entry in delegation_entries:
        name = entry.get("assigned_to", "unknown")
        usage_count[name] = usage_count.get(name, 0) + 1
        last_used[name] = entry["timestamp"]

    success_rate = {}
    if os.path.exists(LOOP_LOG):
        with open(LOOP_LOG, "r") as f:
            loop_entries = json.load(f)
        for session in loop_entries:
            for run in session.get("runs", []):
                if run.get("stopped"):
                    assistant = session.get("assistant", "default")
                    success_rate[assistant] = success_rate.get(assistant, 0) + 1

    scores = {}
    for agent in usage_count:
        score = usage_count[agent]
        score += success_rate.get(agent, 0) * 2
        scores[agent] = {
            "score": score,
            "runs": usage_count[agent],
            "stops": success_rate.get(agent, 0),
            "last_used": last_used.get(agent)
        }

    return scores

if __name__ == "__main__":
    report = score_assistants()
    for agent, data in report.items():
        print(f"{agent}: {data}")
