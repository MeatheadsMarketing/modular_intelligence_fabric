import streamlit as st
import json
import os

st.set_page_config(page_title="Group History")
st.title("Group Task History")

LOG_PATH = "group_log.json"

if os.path.exists(LOG_PATH):
    with open(LOG_PATH, "r") as f:
        logs = json.load(f)
else:
    logs = []

group_filter = st.sidebar.selectbox("Filter by Group", ["All"] + sorted({l["group"] for l in logs}))
filtered = logs if group_filter == "All" else [l for l in logs if l["group"] == group_filter]

st.subheader(f"Group Runs ({len(filtered)})")

for entry in reversed(filtered[-10:]):
    st.markdown("----")
    st.markdown(f"**Group:** `{entry['group']}`")
    st.markdown(f"**Timestamp:** `{entry['timestamp']}`")
    for step in entry["steps"]:
        st.markdown(f"• `{step['assistant']}` → `{step['output']}`")
