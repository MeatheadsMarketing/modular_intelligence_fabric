"""
calendar_logger.py – Assistant Launch Pack v1.9

Creates calendar events via the Google Calendar API based on assistant logs or summaries.
"""

import os
from datetime import datetime, timedelta
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ["https://www.googleapis.com/auth/calendar"]
SERVICE_ACCOUNT_FILE = os.getenv("GOOGLE_SERVICE_ACCOUNT_JSON", "your-service-account.json")
CALENDAR_ID = os.getenv("GOOGLE_CALENDAR_ID", "primary")

def create_event(summary, description="Created by Assistant Launch Pack", duration_minutes=60):
    creds = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)

    service = build("calendar", "v3", credentials=creds)

    now = datetime.utcnow()
    end_time = now + timedelta(minutes=duration_minutes)

    event = {
        "summary": summary,
        "description": description,
        "start": {
            "dateTime": now.isoformat() + "Z",
            "timeZone": "UTC",
        },
        "end": {
            "dateTime": end_time.isoformat() + "Z",
            "timeZone": "UTC",
        }
    }

    try:
        event_result = service.events().insert(calendarId=CALENDAR_ID, body=event).execute()
        print(f"✅ Event created: {event_result.get('htmlLink')}")
    except Exception as e:
        print(f"❌ Failed to create calendar event: {str(e)}")

# Example usage
if __name__ == "__main__":
    create_event("Assistant Weekly Summary Review")
