"""
git_pre_push_hook.py – Git pre-push validator for Assistant Launch Pack

- Enforces folder layout before Git push
- Fails push if structure is invalid or manifest not up-to-date
"""

import os
import sys
import json
from pathlib import Path

VERSIONS = [f"v1.{i}" for i in range(1, 10)] + [f"v2.{i}" for i in range(0, 10)]
SUBFOLDERS = ["tabs", "audit", "handoffs", "idea_log"]
ROOT = Path.cwd()
MANIFEST_PATH = ROOT / "assistant_repo_manifest.json"

def validate_structure():
    if not os.path.exists(MANIFEST_PATH):
        print("❌ Manifest not found. Run enforce_assistant_structure.py first.")
        sys.exit(1)

    with open(MANIFEST_PATH) as f:
        manifest = json.load(f)

    for original_name, expected_path in manifest.items():
        if not Path(expected_path).exists():
            print(f"❌ File missing: {expected_path}")
            sys.exit(1)

    print("✅ All files match manifest. Push allowed.")
    sys.exit(0)

if __name__ == "__main__":
    validate_structure()
