"""
assistant_api.py – Assistant Launch Pack v1.6

Run assistant logic via HTTP POST.
Used for triggering assistants from external scripts or services.
"""

from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import logging
from flow_runner import run_flow, step_echo

HOST = "localhost"
PORT = 8080

class AssistantHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length)

        try:
            payload = json.loads(post_data.decode("utf-8"))
            prompt = payload.get("prompt", "")
            steps = [step_echo]  # Add more dynamic steps later
            result = run_flow(prompt, steps)

            response = {
                "status": "success",
                "data": result
            }
            self.send_response(200)
        except Exception as e:
            logging.exception("Assistant API error")
            response = {"status": "error", "message": str(e)}
            self.send_response(500)

        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(response).encode("utf-8"))

if __name__ == "__main__":
    server = HTTPServer((HOST, PORT), AssistantHandler)
    print(f"✅ Assistant API running at http://{HOST}:{PORT}")
    server.serve_forever()
