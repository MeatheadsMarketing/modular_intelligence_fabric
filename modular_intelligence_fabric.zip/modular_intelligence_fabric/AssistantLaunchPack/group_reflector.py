"""
group_reflector.py – Assistant Launch Pack v2.2

Analyzes group output and provides GPT-based insights on:
- Clarity
- Cohesion
- Strengths
- Suggested improvements
"""

import os
import json
from datetime import datetime
from openai import OpenAI

GROUP_LOG_FILE = "group_log.json"
REFLECTION_LOG_FILE = "group_reflection.json"
client = OpenAI()
model = "gpt-4"

def load_last_group_run():
    if not os.path.exists(GROUP_LOG_FILE):
        return None
    with open(GROUP_LOG_FILE) as f:
        logs = json.load(f)
    return logs[-1] if logs else None

def reflect_on_group_run(entry):
    lines = []
    for step in entry.get("steps", []):
        lines.append(f"{step['assistant']}:
{step['output']}")
    text = "\n\n".join(lines)

    prompt = f"Analyze the following assistant group output:

{text}

Provide feedback on clarity, flow, effectiveness, and improvement opportunities."

    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"❌ GPT Error: {str(e)}"

def save_reflection(reflection, group):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "group": group,
        "summary": reflection
    }

    data = []
    if os.path.exists(REFLECTION_LOG_FILE):
        with open(REFLECTION_LOG_FILE, "r") as f:
            data = json.load(f)

    data.append(entry)
    with open(REFLECTION_LOG_FILE, "w") as f:
        json.dump(data, f, indent=2)

    print("✅ Reflection logged.")

if __name__ == "__main__":
    entry = load_last_group_run()
    if entry:
        reflection = reflect_on_group_run(entry)
        save_reflection(reflection, entry.get("group"))
        print(reflection)
    else:
        print("No group run found.")
