# Forward Hooks
Auto-links to shortcut executor in downstream thread.