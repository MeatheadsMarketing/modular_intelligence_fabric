# 🧠 ThreadFullSpectrumExtraction — v1.0-final

This repository captures and exports GPT thread content with full fidelity — including message logs, shortcut tags, and audit-ready markdown files.

---

## 🚀 How to Run

```bash
# Install dependencies
pip install -r requirements.txt

# Launch Streamlit preview interface
streamlit run interface/run_ui.py
```

## 📂 Output Files

- `exports/thread_export.md` – Full GPT log, markdown-wrapped
- `exports/thread_table.csv` – Summary table
- `exports/audit_log.json` – Extraction logs

---

## 📌 Deployment

```bash
# GitHub release (via script)
bash git_push_release.sh
```

---

## 🔁 Notion Sync

Fill in `.env.example` with your Notion credentials, then run:

```bash
python notion_sync_export_log.py
```