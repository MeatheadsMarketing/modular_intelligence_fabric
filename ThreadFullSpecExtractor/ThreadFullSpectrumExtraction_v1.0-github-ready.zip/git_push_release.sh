#!/bin/bash
set -e

git add .
git commit -m "🔖 Release: ThreadFullSpectrumExtraction v1.0-final"
git tag v1.0-final
git push origin main --tags