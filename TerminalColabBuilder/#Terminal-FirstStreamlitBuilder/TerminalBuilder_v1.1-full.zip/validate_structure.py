#!/usr/bin/env python3

import os
import sys

def validate_structure(path):
    required = ['main_app.py', 'run_ui.py', 'pages']
    missing = [item for item in required if not os.path.exists(os.path.join(path, item))]
    
    if missing:
        print(f"❌ Missing: {', '.join(missing)}")
        return False
    print("✅ Structure looks valid.")
    return True

if __name__ == "__main__":
    if len(sys.argv) < 3 or sys.argv[1] != "--folder":
        print("Usage: python validate_structure.py --folder <folder_name>")
        sys.exit(1)

    folder = sys.argv[2]
    validate_structure(folder)
