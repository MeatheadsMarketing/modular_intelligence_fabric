import streamlit as st
st.title('Base Blank Assistant')
