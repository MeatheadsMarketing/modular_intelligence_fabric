
# Terminal-First Streamlit Builder – System Blueprint (v1.0)

## System Objective
To create a *CLI-first workflow* that scaffolds, validates, and prepares Streamlit assistant apps with perfect structure, zero placeholders, and rapid dev cycles — feeding directly into the audit and deployment stack.

## Components
1. `cli_generate.py` – Builds assistant folder from CLI
2. `run_builder_flow.sh` – Full pipeline: scaffold → validate → manifest → zip
3. `new_assistant.sh` – Minimal shell wrapper
4. `templates/` – Base templates for assistant logic
5. `validate_structure.py` – Linter for folder/file completeness
6. `manifest.json` – Output metadata for downstream systems
