# GPT Thread Recovery Lab

This repository provides a dual-phase system to extract intelligence from GPT threads.

## 🌐 Phase 1: Colab Recovery Lab
Use `GPT_Thread_Recovery_Colab.ipynb` to:
- Upload `.md` GPT thread logs
- Extract tables, code blocks, deep dives, prompt logic
- Push outputs to Google Drive

## 💻 Phase 2: Terminal Engine
Use `run_recovery_terminal.py` to:
- Watch `/watched_threads/` folder
- Auto-run recovery, merging, and role classification
- Save to `/recovered/` and log metadata

## 🔍 Extras
- `streamlit_output_viewer.py`: Visual file browser for extracted intelligence
