# Terminal Engine: GPT Thread Recovery Background Runner
import os, time, subprocess

WATCH_DIR = "./watched_threads"
OUTPUT_DIR = "./recovered"

os.makedirs(OUTPUT_DIR, exist_ok=True)
print("[WATCHING] Folder:", WATCH_DIR)

while True:
    for filename in os.listdir(WATCH_DIR):
        if filename.endswith(".md"):
            input_path = os.path.join(WATCH_DIR, filename)
            print(f"[RUNNING] Recovery on: {filename}")
            subprocess.run(["python3", "gpt_thread_recovery.py", "--input", input_path, "--output", OUTPUT_DIR])
            os.remove(input_path)
    time.sleep(10)
