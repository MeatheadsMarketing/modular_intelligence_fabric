import streamlit as st
import os

st.title("📂 Recovered Thread Intelligence Viewer")
base_dir = "./recovered"

for folder in ["tables", "code_blocks", "deepdives", "prompt_logic"]:
    folder_path = os.path.join(base_dir, folder)
    if os.path.exists(folder_path):
        st.subheader(f"{folder.upper()}")
        for file in os.listdir(folder_path):
            with open(os.path.join(folder_path, file)) as f:
                st.code(f.read(), language='markdown')
